/*$(function(){
	$("#imageCapture").change(function(){
		readURL(this);
	});
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();

			reader.onload = function (e) {
				$('.preview').show();
				$('#preview').attr('src', e.target.result);
			}

			reader.readAsDataURL(input.files[0]);
		}
	}
})*/


// vars
let result = document.querySelector('.result'),
img_result = document.querySelector('.img-result'),
cancel = document.querySelector('.cancel'),
preview = document.querySelector('.preview'),
done = document.querySelector('.done'),
box_2 = document.querySelector('.box-2'),
box_3 = document.querySelector('.box-3'),
img_w = document.querySelector('.img-w'),
img_h = document.querySelector('.img-h'),
options = document.querySelector('.options'),
save = document.querySelector('.save'),
cropped = document.querySelector('.cropped'),
dwn = document.querySelector('.download'),
upload = document.querySelector('#imageCapture'),
loader = document.querySelector('.loader'),
cropper = '';

// on change show image with crop options
upload.addEventListener('change', e => {
  if (e.target.files.length) {
	loader.style.display = 'block';
    // start file reader
    const reader = new FileReader();
    reader.onload = e => {
      if (e.target.result) {
		box_2.classList.remove('hide');
        // create new image
        let img = document.createElement('img');
        img.id = 'image';
        img.src = e.target.result;
        // clean result before
        result.innerHTML = '';
        // append new image
        result.appendChild(img);
        // show save btn and options
        save.classList.remove('hide');
        options.classList.remove('hide');
        // init cropper
        cropper = new Cropper(img);
		loader.style.display = 'none';
      }
    };
    reader.readAsDataURL(e.target.files[0]);
  }
});

cancel.addEventListener('click', e => {
	box_2.classList.add('hide');
	box_3.classList.add('hide');
});
done.addEventListener('click', e => {
	box_2.classList.add('hide');
	box_3.classList.add('hide');
});
// save on click
save.addEventListener('click', e => {
  e.preventDefault();
  // get result to data uri
  let imgSrc = cropper.getCroppedCanvas({
    width: img_w.value // input value
  }).toDataURL();
  // remove hide class of img
  cropped.classList.remove('hide');
  img_result.classList.remove('hide');
  // show image cropped
  cropped.src = imgSrc;
  dwn.classList.remove('hide');
  dwn.download = 'imagename.png';
  dwn.setAttribute('href', imgSrc);
  preview.setAttribute('src', imgSrc);
});
//# sourceURL=pen.js
